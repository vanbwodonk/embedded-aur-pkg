#ifndef __IO_SYSFS_CREATOR__
#define __IO_SYSFS_CREATOR__

#include "sysfs.h"

class IOSysFsMatrixCreator : public IOSysFsGPIO
{
 public:
  IOSysFsMatrixCreator();
};

#endif
