#include "sysfsvoice.h"

IOSysFsMatrixVoice::IOSysFsMatrixVoice()
 : IOSysFsGPIO(17, 27, 23, 22)                     
{
}

