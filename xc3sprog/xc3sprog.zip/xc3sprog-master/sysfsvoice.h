#ifndef __IO_SYSFS_VOICE__
#define __IO_SYSFS_VOICE__

#include "sysfs.h"

class IOSysFsMatrixVoice : public IOSysFsGPIO
{
 public:
  IOSysFsMatrixVoice();
};

#endif
