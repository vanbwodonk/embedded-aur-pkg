#ifndef __IO_MATRIX_VOICE__
#define __IO_MATRIX_VOICE__

#include "iowiringpi.h"

class IOMatrixVoice : public IOWiringPi
{
 public:
  IOMatrixVoice();
};

#endif
