TODO: Improve the verification process
