const char fb_string[]={"${fb_string}"};
