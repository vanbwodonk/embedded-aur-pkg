#include "sysfscreator.h"

IOSysFsMatrixCreator::IOSysFsMatrixCreator()
 : IOSysFsGPIO(4, 17, 22, 27) 
{
}

