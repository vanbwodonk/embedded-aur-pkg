#ifndef __IO_MATRIX_CREATOR__
#define __IO_MATRIX_CREATOR__

#include "iowiringpi.h"

class IOMatrixCreator : public IOWiringPi
{
 public:
  IOMatrixCreator();
};

#endif
